TEAM AND TASK ALLOCATION:
Shivan Kaul Sahib - 260512593
Perl, register, unnecessary prettification

Sangmoon Hwang - 260569675
C, login, accommodating Shivan's neuroses

Alex Makrigiorgos - 260573080
Python, catalogue

-------------------------------------------

The program should work as-is. To ensure that the permissions are set correctly, just type 'make Permission' if things don't work.

The images we used were all gotten from McGill's website. We're reasonably certain these images will not be taken down any time soon, nor will McGill's servers crash, which is why we didn't bother downloading the images onto our deployment server.
